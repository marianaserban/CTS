package serbanpreda.mariana.g1087.builder;

public interface InterfataDescriere {
	public void adaugaBio(String descriere);
}
