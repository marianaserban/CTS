package serbanpreda.mariana.g1087.builder;

public interface InterfataAvatar {
	public void adaugaPoza();
}
