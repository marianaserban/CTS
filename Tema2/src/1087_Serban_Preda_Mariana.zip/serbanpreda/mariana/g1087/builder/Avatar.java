package serbanpreda.mariana.g1087.builder;

public class Avatar implements InterfataAvatar{

	@Override
	public void adaugaPoza() {
		System.out.println("Poza de profil a fost updatata!");
	}

	@Override
	public String toString() {
		return "Avatar []";
	}
}
