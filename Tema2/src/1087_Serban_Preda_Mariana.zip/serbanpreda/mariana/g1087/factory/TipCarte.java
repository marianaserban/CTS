package serbanpreda.mariana.g1087.factory;

public enum TipCarte {
	PUBLICA, PRIVATA;
}
