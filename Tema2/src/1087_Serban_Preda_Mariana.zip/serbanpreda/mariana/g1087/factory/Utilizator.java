package serbanpreda.mariana.g1087.factory;

public class Utilizator {
	
	String numeUtilizator;
	
	public Utilizator(String numeUtilizator) {
		this.numeUtilizator=numeUtilizator;
	}

	@Override
	public String toString() {
		return "Utilizator [numeUtilizator=" + numeUtilizator + "]";
	}
	
}
