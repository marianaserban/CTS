package serbanpreda.mariana.g1087.prototype;

public enum Culoare {
	VERDE, ALBASTRU, ROSU
}
