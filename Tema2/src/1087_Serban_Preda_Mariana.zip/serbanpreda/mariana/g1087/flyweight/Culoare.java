package serbanpreda.mariana.g1087.flyweight;

public enum Culoare {
	ROSU, VERDE, ALBASTRU, GALBEN
}
