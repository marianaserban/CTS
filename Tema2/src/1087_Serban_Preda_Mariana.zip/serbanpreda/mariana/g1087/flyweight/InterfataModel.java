package serbanpreda.mariana.g1087.flyweight;

public interface InterfataModel {
	public void desenare(Ecran context);
}
