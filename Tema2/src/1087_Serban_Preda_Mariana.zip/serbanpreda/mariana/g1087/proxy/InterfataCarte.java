package serbanpreda.mariana.g1087.proxy;

public interface InterfataCarte {
	
	public String getTitlu();
	public String getAutor();
	public double getRating();
	public void print();
}
