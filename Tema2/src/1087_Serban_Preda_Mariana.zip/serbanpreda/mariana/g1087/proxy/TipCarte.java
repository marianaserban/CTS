package serbanpreda.mariana.g1087.proxy;

public enum TipCarte {
	PUBLICA, PRIVATA
}
